set interval digunakan untuk memberi waktu
set color adalah function yang sudah dibuat
